
public class Test2 {
	void mul(double x,double y) {
		System.out.println("����="+x*y);
	}

}
